<?php
[ 'item1', 'item2', 'item3' ];
[ 'item1' => 'item2',
  'item3' => 'item4' ]
