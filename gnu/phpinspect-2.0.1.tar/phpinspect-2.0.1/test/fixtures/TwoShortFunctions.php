<?php
function work() {
    return $variable;
}

function work2() {
    return $paper;
}
