
# Checklist:

- [ ] I have signed the FSF copyright assignment form for Emacs
- [ ] I have NOT signed the FSF copyright assignment form for Emacs but this change is trivial (<15 lines), I have no other code contributed to Emacs and I have included a line `Copyright-paperwork-exempt: yes` in the commit message
