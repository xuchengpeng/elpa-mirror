package main

import (
	_ "github.com/xo/usql/drivers/clickhouse"
	_ "github.com/xo/usql/drivers/csvq"
	_ "github.com/xo/usql/drivers/mysql"
	_ "github.com/xo/usql/drivers/oracle"
	_ "github.com/xo/usql/drivers/postgres"
	_ "github.com/xo/usql/drivers/sqlite3"
	_ "github.com/xo/usql/drivers/sqlserver"
)
