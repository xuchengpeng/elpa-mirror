<?php
function work() {
    return $variable;
}
