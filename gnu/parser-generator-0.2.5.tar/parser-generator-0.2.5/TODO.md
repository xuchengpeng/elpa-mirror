# TODO / Roadmap / Issues

## Main

Functions (with validations) to set global variables:

* parser-generator--context-sensitive-attributes
* parser-generator--global-attributes
* parser-generator--global-declaration

## LR-Parser

Functions (with validations) to set global variables:

* parser-generator-lr--context-sensitive-precedence-attribute
* parser-generator-lr--global-precedence-attributes

[Back to start](../../)
