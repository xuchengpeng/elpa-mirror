[![ELPA](https://elpa.gnu.org/packages/ess.svg)](https://elpa.gnu.org/packages/ess.html)
[![MELPA Stable](http://stable.melpa.org/packages/ess-badge.svg)](https://stable.melpa.org/#/ess)
[![MELPA](http://melpa.org/packages/ess-badge.svg)](https://melpa.org/#/ess)
<!--- [![Build Status](https://travis-ci.org/emacs-ess/ESS.svg?branch=master)](https://travis-ci.org/emacs-ess/ESS) --->

# ESS

Git development branch of Emacs Speaks Statistics: ESS.
For more info, see our web page at https://ess.r-project.org/

