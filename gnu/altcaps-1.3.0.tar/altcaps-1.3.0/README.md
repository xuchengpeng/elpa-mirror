# aLtCaPs

The `altcaps` package is a small, focused-in-scope tool that helps
users communicate mockery or sarcasm effectively.  It does this by
alternating the letter casing of characters in the words it affects.

+ Package name (GNU ELPA): `altcaps`
+ Official manual: <https://protesilaos.com/emacs/altcaps>
+ Change log: <https://protesilaos.com/emacs/altcaps-changelog>
+ Git repositories:
  + GitHub: <https://github.com/protesilaos/altcaps>
  + GitLab: <https://gitlab.com/protesilaos/altcaps>
+ Backronyms: Alternating Letters Transform Casual Asides to Playful
  Statements.  ALTCAPS Lets Trolls Convert Aphorisms to Proper
  Shitposts.
