ioccur
======

incremental occur for Emacs

Probably you will want to use and enhanced version supporting multiples buffers and more
by using the [helm](https://github.com/emacs-helm/helm) version.
