# org-notify
Notifications for Org-mode

Available on GNU ELPA: https://elpa.gnu.org/packages/org-notify.html
