This package is superceded by the `textsec.el` packages included in Emacs≥29.
