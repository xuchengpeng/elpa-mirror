# show-font for GNU Emacs

DEMO HERE: <https://protesilaos.com/codelog/2024-08-24-emacs-show-font-prototype/>.

This package lets you preview a font inside of Emacs. It does so in
three ways:

- Prompt for a font on the system and display it in a buffer.
- List all known fonts in a buffer, with a short preview for each.
- Provide a major mode to preview a font whose file is among the
  installed ones.

## Sources

+ Package name (GNU ELPA): `show-font`
+ Official manual: <https://protesilaos.com/emacs/show-font>
+ Change log: <https://protesilaos.com/emacs/show-font-changelog>
+ Git repository: <https://github.com/protesilaos/show-font>
+ Backronym: Show How Outlines Will Feature Only in Non-TTY.
