# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [Unreleased]

### Added

### Changed

### Deprecated

### Removed

### Fixed

### Security

## [0.2] - 2025-04-18

### Fixed

- Properly escape filenames containing jj fileset operator characters.

## [0.1] - 2025-03-16

### Added

- First released version.

[unreleased]: https://codeberg.org/emacs-jj-vc/vc-jj.el/compare/v0.2...HEAD
[0.2]: https://codeberg.org/emacs-jj-vc/vc-jj.el/compare/v0.1...v0.2
[0.1]: https://codeberg.org/emacs-jj-vc/vc-jj.el/src/tag/v0.1
