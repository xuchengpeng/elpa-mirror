
This provides a literate web server for Emacs. "literate", means
documentation which has been co-created along with the source code for Emacs
packages with the [lentic](https://github.com/phillord/lentic) package.

The main entry points are M-x lentic-server-start and lentic-server-stop.

This is an early release!


