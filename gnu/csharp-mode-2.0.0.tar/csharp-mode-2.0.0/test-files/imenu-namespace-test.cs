using System;

namespace ImenuTest
{
    public interface ImenuTestInterface
    {
    }

    public class ImenuTestClass
    {
    }

    public enum ImenuTestEnum
    {
    }
}
