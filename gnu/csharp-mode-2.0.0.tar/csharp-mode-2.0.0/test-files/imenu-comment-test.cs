using System;

public class MyClass
{
    public void HasComment() // test
    {
    }

    public void HasNoComment()
    {
    }

    public void CommentedToo() /* test yes */
    {
    }
}
