public const string Literal0 = @"\
";
public const string Literal1 = @"\";
public const string Literal2 = @"\\";
public const string Literal3 = @"\\\";
public const string Literal4 = @$"\\\\";
public const string Literal5 = $@"\\\\
";
public const string Literal6 = "\t\t/* We need to ensure that \"{0}\"comes first in this list. */";
public const string Literal7 = "";
