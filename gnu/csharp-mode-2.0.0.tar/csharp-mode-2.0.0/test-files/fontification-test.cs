
public const string Literal1 = @"literal without trailing slash";
public const bool1 Reference = true;
public const bool2 Reference = true;
public static const string Literal3 = @"multi-line
literal";
