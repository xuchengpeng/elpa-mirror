;; Commented Code

;; \begin{code}
(form inserted)
(comment "code")
;; \end{code}

;; Commented Code
