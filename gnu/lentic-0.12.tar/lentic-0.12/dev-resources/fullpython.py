#!/usr/bin/python

## #+BEGIN_SRC python
print("Hello World")
## #+END_SRC

## Local Variables:
## lentic-init: lentic-python-script-init
## End:
