;; Commented Code
;; inserted

;; \begin{code}
(comment "code")
;; \end{code}

;; Commented Code
