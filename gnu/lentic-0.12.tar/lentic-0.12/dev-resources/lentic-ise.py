#!/usr/bin/python

## This part of the file is documentation.

print( "hello world" )
