
;; * An org file

;; #+BEGIN_SRC clojure
(message "hello")
;; #+END_SRC
