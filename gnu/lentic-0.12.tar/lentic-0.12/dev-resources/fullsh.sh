#!/bin/bash

## #+begin_src sh
echo "hello world"
## #+end_src

## # Local Variables:
## # lentic-init: lentic-bash-script-init
## # End:
