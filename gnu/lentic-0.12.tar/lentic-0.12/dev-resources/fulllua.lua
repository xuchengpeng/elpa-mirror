#!/usr/bin/env lua

-- #+BEGIN_SRC lua
print( "Hello World" )
-- #+END_SRC

-- # Local Variables:
-- # lentic-init: lentic-lua-script-init
-- # End:
