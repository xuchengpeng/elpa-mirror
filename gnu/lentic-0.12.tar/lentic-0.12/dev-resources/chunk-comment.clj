;; Commented Code

;; \begin{code}
(comment "code")
;; \end{code}

;; Commented Code
