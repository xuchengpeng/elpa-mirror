;; This is markdown and this is working very nicely

;; ```{.clojure}
(println "hello big world")
;; ```



;; Local Variables:
;; lentic-init: lentic-clojure-markdown-init
;; End:
