# #!/usr/bin/python

# #+begin_src python
# print("Hello World")
# #+end_src



# Hello is this working? and what about this.

# I do not know what is going to be able to happen here.





# So this is all working nicely, now let's break things.

# But anything I comment in here will do the correct thing.


# #+begin_comment

# We need to comment this using both org comments and python comments. But,
# sadly, they share the same syntax for line starter comments.

# Local Variables:
# lentic-init: lentic-python-org-init
# End:
# #+end_comment


