[![Build Status](https://travis-ci.org/emacs-ess/ESS.svg?branch=master)](https://travis-ci.org/emacs-ess/ESS)
[![MELPA Stable](http://stable.melpa.org/packages/ess-badge.svg)](https://stable.melpa.org/#/ess)
[![MELPA](http://melpa.org/packages/ess-badge.svg)](https://melpa.org/#/ess)

# ESS

Git development branch of Emacs Speaks Statistics: ESS.
For more info, see our web page at https://ess.r-project.org/

