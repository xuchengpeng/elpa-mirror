<?php
$variable
