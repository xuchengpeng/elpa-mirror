package main

type A int

func (A) Foo() (A,
	A) {
	// Code goes here
}
