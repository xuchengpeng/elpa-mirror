package main

var foo =
// hello
123

var foo = 123 +
	// hello
	123

const foo =
// hello
123

const foo = 123 +
	// hello
	123

type foo =
// hello
int

func main() {
	var foo =
	// hello
	123

	var foo = 123 +
		// hello
		123

	const foo =
	// hello
	123

	const foo = 123 +
		// hello
		123

	type foo =
	// hello
	int

	foo :=
		// hello
		123
}
