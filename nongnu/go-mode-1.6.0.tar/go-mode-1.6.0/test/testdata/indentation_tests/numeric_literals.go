package main

func main() {
	1234.
	hi()

	-1234.
	hi()

	oneTwo3.
		hi()
}
