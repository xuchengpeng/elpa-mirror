package gh15

func somewhatLongFunctionName(
	arg1 package1.RatherLongTypeName, arg3 struct{}) {
	return
}

func foo(arg1 type1,
	arg2 type2,
	arg3 type3) {
	return
}
