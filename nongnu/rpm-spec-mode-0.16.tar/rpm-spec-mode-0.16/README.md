rpm-spec-mode
=============

RPM spec file editing commands for Emacs/XEmacs
