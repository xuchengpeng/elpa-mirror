<?php

/**
 * GitHub Issue:    https://github.com/emacs-php/php-mode/issues/174
 *
 * Test highlighting of string literals containing escaped quotes
 */

'escaped single \' quotation mark';
"escaped double \" quotation mark";
