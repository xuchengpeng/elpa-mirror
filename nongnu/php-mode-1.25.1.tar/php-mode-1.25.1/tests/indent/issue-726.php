<?php
$a = [
    'aaa' => [
        'bee' => 2,
    ],
    // 'foo' => [
    //      'bar' => 1,
    // ],
    // ###php-mode-test### ((indent 4))
    'lee' => 2,
    // 'dee' => 3
    'gee' => 4, // ###php-mode-test### ((indent 4))
]; // ###php-mode-test### ((indent 0))
