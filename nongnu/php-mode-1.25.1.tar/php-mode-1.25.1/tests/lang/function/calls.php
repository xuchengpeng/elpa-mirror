<?php

if (isset($foo)) {
    1+bar()+foo();
}

$foo->string();
$foo->isset();


$a->b();
$a = a();
$aaa = aaa();
$_aa = _aa();
$a_a = a_a();
$aa_ = aa_();
$a1c = a1c();
$あ = あ();
$_a = $a();
