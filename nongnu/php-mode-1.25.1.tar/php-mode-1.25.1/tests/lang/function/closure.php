<?php

is_object(static function () {
    // ###php-mode-test### ((indent 4))
});

is_object(static function (): void {
    // ###php-mode-test### ((indent 4))
});
