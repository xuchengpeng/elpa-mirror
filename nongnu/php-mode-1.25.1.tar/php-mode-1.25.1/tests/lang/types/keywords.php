<?php

__halt_compiler();

bool;
boolean;
int;
integer;
float;
double;
real;
string;
object;
resource;
mixed;
