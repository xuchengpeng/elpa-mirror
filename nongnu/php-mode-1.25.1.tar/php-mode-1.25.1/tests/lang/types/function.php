<?php

function (bool $args) {};
function (boolean $args) {};
function (int $args) {};
function (integer $args) {};
function (float $args) {};
function (double $args) {};
function (real $args) {};
function (string $args) {};
function (object $args) {};
function (resource $args) {};
