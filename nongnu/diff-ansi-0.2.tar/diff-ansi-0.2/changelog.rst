
##########
Change Log
##########

- Version 0.2 (2022-07-08)

  - Add ``diff-ansi-verbose-progress`` to support showing progress for progressive ansi conversion.
  - Fix error running the ``progressive`` timer that could be canceled by external actions.

- Version 0.1 (2021-10-21)

  Initial release.
