(ns bar
  (:require [foo]))
