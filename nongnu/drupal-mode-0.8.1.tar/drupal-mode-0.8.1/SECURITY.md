# Security Policy

## Supported Versions

All versions are supported.

## Reporting a Vulnerability

Security issues can be reported to [Arne Jørgensen](https://github.com/arnested)
either by [mail](mailto:arne@arnested.dk) or any other channel you prefer and
trust (see my [Keybase profile](https://keybase.io/arnested)).
