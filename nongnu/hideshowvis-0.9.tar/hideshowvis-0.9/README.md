# hideshowvis

Add little clickable +/- icons in the Emacs fringe for regions which Emacs' hideshow.el can hide.

![Screenshot](screenshot.png)

By Jan Rehders, <jan@sheijk.net>
