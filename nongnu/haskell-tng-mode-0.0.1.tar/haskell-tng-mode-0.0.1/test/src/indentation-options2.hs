-- | Indentation scenarios to test indentation options.
module Indentation where

types5 :: Monad m
       => (?log :: HasLogger m)
       => a
       -> b
       -> c

types6 ::
        ( Monad m )
       => a
       -> b
       -> c
