#!/bin/bash

cd ..

find . -name "*.elc" -type f -delete
