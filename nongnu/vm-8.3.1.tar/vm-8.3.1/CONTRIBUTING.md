# Development and getting involved

First of all, thank you for helping in improving VM!

We maintain the source code in [Git](https://git-scm.com/) at the
[Gitlab](https://gitlab.com/emacs-vm/vm) forge.

If you want to get the latest development version of VM you may clone
from there, see the button `Code`. If you want to contribute changes
you may want to
[fork](https://docs.gitlab.com/ee/user/project/repository/forking_workflow.html)
the repository. The project's [issue
tracker](https://gitlab.com/emacs-vm/vm/-/issues) is where we keep
track of the bugs that need fixing as well as items on the wishlist.
