All the work in this directory is distributed under
[CC-BY](https://creativecommons.org/licenses/by/4.0/)
