![Emacs](https://dl.dropbox.com/u/476562/screenshots/emacs.png)
