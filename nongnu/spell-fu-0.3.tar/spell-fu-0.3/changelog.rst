
##########
Change Log
##########

- Version 0.3 (2021-03-28)

  - Support affix expansion when calling ``aspell`` (some non English dictionaries use this).
  - Use explicit ``utf-8`` encoding, (fixes issue #8).

- Version 0.2 (2020-04-26)

  - Add support personal dictionary manipulation: ``spell-fu-word-add``, ``spell-fu-word-remove``.
  - Add support for stepping over errors with: ``spell-fu-goto-next-error``, ``spell-fu-goto-previous-error``.
  - Add support for checking the whole buffer with: ``spell-fu-buffer``.

- Version 0.1 (2020-04-14)

  Initial release.
