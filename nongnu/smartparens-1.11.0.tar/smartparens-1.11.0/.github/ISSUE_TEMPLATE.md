## Expected behavior



## Actual behavior



## Steps to reproduce the problem



## Backtraces if necessary (`M-x toggle-debug-on-error`)



## Environment & version information

**In recent enough `smartparens` you can call `M-x sp-describe-system` to generate this report**.  Please fill manually what we could not detect automatically.  Edit the output as you see fit to protect your privacy.

- `smartparens` version:
- Active major-mode:
- Emacs version (`M-x emacs-version`):
- Spacemacs/Evil/Other starterkit (specify which)/Vanilla:
- OS:
