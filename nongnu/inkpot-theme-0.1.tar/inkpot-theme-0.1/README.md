emacs24-inkpot
==============

a port of the vim inkpot theme for emacs deftheme

This theme is still rough, but I've taken Per Vognsen's port of vim's wonderful inkpot, added some extra faces for org and gnus, and ported it to use the deftheme architecture. 

You can find Per Vognsen's original at http://www.emacswiki.org/emacs/ColorThemeInkpot.

Additions, corrections, and improvements are most welcome.