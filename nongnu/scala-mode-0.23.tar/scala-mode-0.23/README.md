Documentation is available at [ensime.org](http://ensime.github.io/editors/emacs/scala-mode/).
