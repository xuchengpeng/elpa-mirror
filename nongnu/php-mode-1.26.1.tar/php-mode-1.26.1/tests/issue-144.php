<?php

/**
 * GitHub Issue:    https://github.com/emacs-php/php-mode/issues/144
 *
 * Indentation test '#' comment line has single quote.
 *
 */

# This project's homepage is  http://www.website.com
$a = 1;
if( $a == 1 ) {
$a = $a + 1;
}
?>
