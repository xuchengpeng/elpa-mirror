<?php

/**
 * GitHub Issue:    https://github.com/emacs-php/php-mode/issues/201
 *
 * Test highighting of $this
 */

// Start:
$this;
$that;
self::test();
static::test();
parent::test();
