<?php

#[
 Deprecated
]
function f($arg1,
 #[Deprecated] $arg2){}
#Deprecated
