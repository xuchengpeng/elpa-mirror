<?php

/**
 * GitHub Issue:    https://github.com/emacs-php/php-mode/issues/200
 *
 * There are extra whitespaces in the code below. In PSR-2 mode, those must be
 * highlighted and stripped upon save (be careful when editing and saving,
 * then)
 */

class Foo
{
    public function test()   
    {
             
    }   
}


