<?php

$var = 1;

(array)$var;
(binary)$var;
(bool)$var;
(boolean)$var;
(float)$var;
(int)$var;
(integer)$var;
(object)$var;
(real)$var;
(string)$var;
(unset)$var;
