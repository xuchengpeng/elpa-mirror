<?php

echo __LINE__, PHP_EOL;
echo __FILE__, PHP_EOL;
echo __FILE__, PHP_EOL;
echo __FUNCTION__, PHP_EOL;
echo __CLASS__, PHP_EOL;
echo __TRAIT__, PHP_EOL;
echo __METHOD__, PHP_EOL;
echo __NAMESPACE__, PHP_EOL;
echo \Directory::class, PHP_EOL;
