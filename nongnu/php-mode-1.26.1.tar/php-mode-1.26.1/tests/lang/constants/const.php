<?php

const A = 'A';
const a = 'a';
const B='B';
const b='b';
const Aa = 'Aa';
const AA = 'AA';
const AB='AB';
const Ab='AA';
const α = '';
const Ａ = '';
const ａ = '';
const あ = 'あ';
const 漢 = '漢';
const あα = 'あα';
const 漢_ = '漢_';
const あ_='あ_';
const X='X';const y='y';
