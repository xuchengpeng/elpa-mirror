<?php

/**
 * PSR-5 style tag annotation
 */

/**
 * @MyProject\Annotations\Foobarable
 */
class User
{
}

/**
 * @property-read string $myProperty
 */
class Child extends Parent_
{
}
