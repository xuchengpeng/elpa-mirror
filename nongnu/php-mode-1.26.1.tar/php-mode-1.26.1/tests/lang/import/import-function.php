<?php
namespace Foo;

use function var_dump;
use function is_array, is_string, is_dir;
use function Safe\json_encode;
use function Safe\{file_get_contents, json_decode};
