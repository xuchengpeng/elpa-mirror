<?php
namespace Foo;

use const Foo\BAR;
use const Foo\{BUZ, BUZBUZ};
use const PHP_VERSION;

const FOO = 'bar';
