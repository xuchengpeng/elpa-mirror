<?php

function a() : string {
    return 'world';
}
echo 'hello'; // ###php-mode-test### ((indent 0))