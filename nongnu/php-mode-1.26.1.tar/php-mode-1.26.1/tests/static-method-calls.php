<?php

ClassName::method();
\Project\Module\ClassName::method();
\ClassName::method();

ClassName::new();
\Project\Module\ClassName::new();
\ClassName::new();

ClassName::clone();
\Project\Module\ClassName::clone();
\ClassName::clone();
