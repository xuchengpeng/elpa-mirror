<?php

/**
 * GitHub Issue:    https://github.com/emacs-php/php-mode/issues/197
 *
 * Test that member highlighting goes before highlighting of cc-mode
 * types
 */
$test->array;
$test->int;
$test->string;
$test->int();
$test->string();
