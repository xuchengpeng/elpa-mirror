<?php

/**
 * GitHub Issue:    https://github.com/emacs-php/php-mode/issues/175
 *
 * PHP mode should not highlight more than 2 digit charcter
 *
 */

return [1,2,3,4,5,6,7,8,9,10];
