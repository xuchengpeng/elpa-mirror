<?php

/**
 * GitHub Issue:    https://github.com/emacs-php/php-mode/issues/305
 *
 * Test highighting of $this_foo, $that_foo
 */

// Start:
$this_foo;
$that_foo;
