(defproject cider-tramp-dev "0"
  :dependencies [[org.clojure/clojure "1.11.1"]
                 [clj-http "3.12.3"]]
  :source-paths ["src"]
  :plugins [[cider/cider-nrepl "0.52.0"]
            [refactor-nrepl "3.9.0"]])
