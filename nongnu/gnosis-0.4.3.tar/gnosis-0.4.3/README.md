# Γνῶσις | Gnosis

## About

Γνῶσις (gnosis), pronounced "GNU-sis", meaning knowledge in Greek,
is a GNU Emacs Spaced Repetition System for storing knowledge.

- [Project's Page](https://thanosapollo.org/projects/gnosis/)
- [User Manual](https://elpa.nongnu.org/nongnu/doc/gnosis.html)
