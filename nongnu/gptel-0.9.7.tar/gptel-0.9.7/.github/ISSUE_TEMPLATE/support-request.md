---
name: Support request
about: Help or support for gptel
title: ''
labels: question
assignees: ''

---

**Briefly describe what you are trying to do**



**Additional context**
Emacs version:
Operating system:
