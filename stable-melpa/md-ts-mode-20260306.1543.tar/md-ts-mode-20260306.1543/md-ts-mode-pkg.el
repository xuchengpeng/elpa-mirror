;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "md-ts-mode" "20260306.1543"
  "Major mode for Markdown using tree-sitter."
  '((emacs "29.1"))
  :url "https://github.com/dnouri/md-ts-mode"
  :commit "f7023b943d813e877437de4c1ca28f8116e2df46"
  :revdesc "f7023b943d81"
  :keywords '("markdown" "languages" "tree-sitter")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
