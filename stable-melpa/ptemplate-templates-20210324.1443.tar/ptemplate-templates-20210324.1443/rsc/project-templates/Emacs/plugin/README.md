# About

Like the `cask-plugin` template (which see), the only difference being that no
Caskfile is generated.
