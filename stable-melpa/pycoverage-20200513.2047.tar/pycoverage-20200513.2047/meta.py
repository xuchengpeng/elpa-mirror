# Copyright (c) 2009 Matt Harrison

__version__ = '0.1.1'
__author__ = 'Matt Harrison'
__email__ = 'matthewharrison at gmail.com'
