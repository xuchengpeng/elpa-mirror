# python rmsbolt starter file
#
# Local Variables:
# rmsbolt-command: "python3"
# End:

RMS_MAP = {
    'R': 3,
    'M': 3,
    'S': 3
}

def isRMS(char):
    return 3

print(isRMS('R'))
