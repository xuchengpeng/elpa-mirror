def print_banner(tmpfile):
    pyvterm_dump_json(tmpfile, True)
