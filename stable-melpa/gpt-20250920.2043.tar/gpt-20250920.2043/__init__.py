"""Provider implementations for gpt.py."""
